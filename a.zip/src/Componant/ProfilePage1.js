import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
// import fetch from 'node-fetch';

const ProfilePage1 = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch(`https://dummyjson.com/users/${user.id}`);
        const data = await response.json();
        dispatch({ type: 'LOGIN_SUCCESS', payload: data });
      } catch (error) {
        console.log(error);
      }
    };

    if (user) {
      fetchUser();
    }
  }, [user, dispatch]);

  return (
    <div>
      <h1>Profile</h1>
      {user && (
        <div>
          <p>Name: {user.name}</p>
          <p>Email: {user.email}</p>
          <p>Phone: {user.phone}</p>
        </div>
      )}
    </div>
  );
};

export default ProfilePage1